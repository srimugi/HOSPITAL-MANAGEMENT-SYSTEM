package com.example.demo.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Entity.Patient;
import com.example.demo.Error.PatientNotFoundException;
import com.example.demo.Repository.ReceptionistRepository;

@Service
public class ReceptionistServiceImpl implements ReceptionistService{
	
	
	@Autowired
	ReceptionistRepository receptionistRepository;
	
//***********************GET ALL PATIENT**********************
	
		@Override
		public List<Patient> fetchPatientList() {
			
			return receptionistRepository.findAll();
		}
	
//************************ADD PATIENT*************************
	
		@Override
		public Patient savePatient(Patient patient) {
			
			return receptionistRepository.save(patient);
		}

		
//************************DELETE PATIENT**********************
		
		@Override
		public void deletePatientById(Integer aid) throws PatientNotFoundException {
			Optional<Patient> pat=receptionistRepository.findById(aid);
			if(!pat.isPresent())
			{
				throw new PatientNotFoundException("Doctor Id is Not Available Cannot Delete");
			}
			else {
					
			receptionistRepository.deleteById(aid);
			}
		}
		
//************************UPDATE PATIENT**********************
		@Override
		public Patient updatePatient(Integer aid, Patient patient) throws PatientNotFoundException {
			
		
				Optional<Patient> pat=receptionistRepository.findById(aid);
				Patient patDB=null;
				if(pat.isPresent())
				{
					 patDB=	receptionistRepository.findById(aid).get();
					if(Objects.nonNull(patient.getPname()) && !"".equalsIgnoreCase(patient.getPname())) {
						patDB.setPname(patient.getPname());
						
					}
		
					if(Objects.nonNull(patient.getAge()) && !"".equalsIgnoreCase(patient.getAge())) {
						patDB.setAge(patient.getAge());
						
					}
					if(Objects.nonNull(patient.getDob()) && !"".equals(patient.getDob())) {
						patDB.setDob(patient.getDob());
						
					}
					if(Objects.nonNull(patient.getPname()) && !"".equalsIgnoreCase(patient.getPname())) {
						patDB.setPname(patient.getPname());
						
					}
					if(Objects.nonNull(patient.getGender()) && !"".equalsIgnoreCase(patient.getGender())) {
						patDB.setGender(patient.getGender());
						
					}
					if(Objects.nonNull(patient.getContactno()) && !"".equalsIgnoreCase(patient.getContactno())) {
						patDB.setContactno(patient.getContactno());
						
					}
					if(Objects.nonNull(patient.getAddress()) && !"".equalsIgnoreCase(patient.getAddress())) {
						patDB.setAddress(patient.getAddress());
						
					}
					if(Objects.nonNull(patient.getReason()) && !"".equalsIgnoreCase(patient.getReason())) {
						patDB.setReason(patient.getReason());
						
					}
					if(Objects.nonNull(patient.getAppointmentdate()) && !"".equals(patient.getAppointmentdate())) {
						patDB.setAppointmentdate(patient.getAppointmentdate());
						
					}
					if(Objects.nonNull(patient.getStatus()) && !"".equalsIgnoreCase(patient.getStatus())) {
						patDB.setStatus(patient.getStatus());
						
					}
					if(Objects.nonNull(patient.getFee()) && !"".equals(patient.getFee())) {
						patDB.setFee(patient.getFee());
						
					}
					return receptionistRepository.save(patient);
				}
				else
				{
					throw new PatientNotFoundException("Please Enter Valid Data to Update the Record");
				}
			
		}

//***********************GET PATIENT DETAILS BY NAME*************
		@Override
		public Patient fetchPatientByPname(String pname) throws PatientNotFoundException {
			Optional<Patient> pat=receptionistRepository.findPatientByPname(pname);
			if(!pat.isPresent())
			{
				throw new PatientNotFoundException("Patient Name is Not Available Cannot Get Details");
			}
			else {
			return receptionistRepository.findPatientByPname(pname).get();
			}
		}
		
		

}
