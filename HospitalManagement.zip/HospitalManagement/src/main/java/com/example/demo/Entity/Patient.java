package com.example.demo.Entity;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Appointment_Details")
public class Patient {
	@Id
	@GeneratedValue
	private int aid;
	@Column(name = "PatientName")
	@NotBlank(message="Patient Name cannot be Blank")
	private String pname;
	@Column(name="PatientAge")
	@NotBlank(message = "patiet Age Cannot be Blank")
		private String age;
	@Column(name="DateOfBirth")
		@Temporal(TemporalType.DATE)
		@DateTimeFormat(pattern = "yyyy-mm-dd")
		private Date dob;
	@Column(name = "Gender")
		private String gender;
	@Column(name = "ContactNumber")
	@Length(min = 10, max = 13, message = "Mobile number cannot be less than 10 Character")
		private String contactno;
			@Column(name="Address")
			@Length(min = 3,message = "Address value must contains atleast 3 character")
			private String address;
	@Column(name="Reason")
	@NotBlank(message = "Reason cannot be Blank")
	private String reason;
		@Column(name="Date")
		@Temporal(TemporalType.DATE)
		@DateTimeFormat(pattern = "yyyy-mm-dd")
		private Date appointmentdate;
			@Column(name = "Status")
			private String status;
	@Column(name = "DoctorFee")
	@Range(min = 250, message = "Miminum Fees is 250")
	private double fee;
	public Patient() {
		super();
	}
	public Patient(int aid, @NotBlank(message = "Patient Name cannot be Blank") String pname,
			@NotBlank(message = "patiet Age Cannot be Blank") String age, Date dob, String gender,
			@Length(min = 10, max = 13, message = "Mobile number cannot be less than 10 Character") String contactno,
			@Length(min = 3, message = "Address value must contains atleast 3 character") String address,
			@NotBlank(message = "Reason cannot be Blank") String reason, Date appointmentdate, String status,
			@Range(min = 250, message = "Miminum Fees is 250") double fee) {
		super();
		this.aid = aid;
		this.pname = pname;
		this.age = age;
		this.dob = dob;
		this.gender = gender;
		this.contactno = contactno;
		this.address = address;
		this.reason = reason;
		this.appointmentdate = appointmentdate;
		this.status = status;
		this.fee = fee;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Date getAppointmentdate() {
		return appointmentdate;
	}
	public void setAppointmentdate(Date appointmentdate) {
		this.appointmentdate = appointmentdate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	@Override
	public String toString() {
		return "Patient [aid=" + aid + ", pname=" + pname + ", age=" + age + ", dob=" + dob + ", gender=" + gender
				+ ", contactno=" + contactno + ", address=" + address + ", reason=" + reason + ", appointmentdate="
				+ appointmentdate + ", status=" + status + ", fee=" + fee + "]";
	}
	
}
