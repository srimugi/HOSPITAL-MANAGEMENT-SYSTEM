package com.example.demo.Service;


import java.util.List;
import com.example.demo.Entity.Patient;
import com.example.demo.Error.PatientNotFoundException;

public interface ReceptionistService {

	Patient savePatient(Patient patient);
	
	void deletePatientById(Integer pid) throws PatientNotFoundException;

	Patient updatePatient(Integer pid, Patient patient) throws PatientNotFoundException;

	List<Patient> fetchPatientList();

	Patient fetchPatientByPname(String pname) throws PatientNotFoundException;

	

}
