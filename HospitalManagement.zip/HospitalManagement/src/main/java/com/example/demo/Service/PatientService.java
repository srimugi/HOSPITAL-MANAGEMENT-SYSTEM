package com.example.demo.Service;


import com.example.demo.Entity.Patient;
import com.example.demo.Error.PatientNotFoundException;

public interface PatientService {

	Patient fetchPatientById(Integer aid) throws PatientNotFoundException;


}
